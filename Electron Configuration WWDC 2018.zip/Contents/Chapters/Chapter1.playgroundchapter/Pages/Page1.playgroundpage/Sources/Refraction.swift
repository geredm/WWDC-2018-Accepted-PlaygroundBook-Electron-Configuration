//  Copyright (c) 2018 Geremia De Micco. All Rights Reserved.

import UIKit
import SpriteKit
import PlaygroundSupport


public class RefractionScene: SKScene{
    
    //SKShapeNode
    public var pyramidNode = SKShapeNode()
    public var torchNode = SKSpriteNode()
    
    //ghosts
    public var redGhost = SKSpriteNode()
    public var blueGhost = SKSpriteNode()
    public var greenGhost = SKSpriteNode()
    public var redGhostTextures0: [SKTexture] = []
    public var blueGhostTextures0: [SKTexture] = []
    public var greenGhostTextures0: [SKTexture] = []
    public var redGhostTextures2: [SKTexture] = []
    public var blueGhostTextures2: [SKTexture] = []
    public var greenGhostTextures2: [SKTexture] = []
    public var redGhostTextures3: [SKTexture] = []
    public var blueGhostTextures3: [SKTexture] = []
    public var greenGhostTextures3: [SKTexture] = []
    public var selectedNode = SKSpriteNode()
    public var ghostTouched = false
    public var lightTouched = false
    
    public var firstFail = true
    public var firstTryAgain = true
    public var firstTimeSetup = true
    
    
    //SKEmitterNode
    public var lightNode = SKEmitterNode()
    public var blueNode = SKEmitterNode()
    public var blueGhostAnimation: SKAction?
    public var newBlueColor = UIColor()
    public var newRedColor = UIColor()
    public var newGreenColor = UIColor()
    public var blueGhostColorAnimation: SKAction?
    public var redGhostColorAnimation: SKAction?
    public var greenGhostColorAnimation: SKAction?
    public var redNode = SKEmitterNode()
    public var redGhostAnimation: SKAction?
    public var greenNode = SKEmitterNode()
    public var greenGhostAnimation: SKAction?
    
    //UIView
    public var instructionView = UIView()
    public var originaFrameView = CGRect()
    public var button = UIButton()
    public var letsStart: Bool = false
    
    //Phases
    public var phase = -1
    public var ExperimentCompleted = false
    
    //debug Properties
    public var scaleLight = CGFloat()
    public var centerScene = CGPoint()
    public var lastUpdateTime :TimeInterval = 0
    public var dt: TimeInterval = 0
    public var dtLightFlow: CGFloat = 0     //second
    public var v0LightFlow: CGFloat = 180    //point/second
    public var dxLightpyramid: CGFloat = 0    //pointX
    public var dyLightpyramid: CGFloat = 0    //pointY
    
    public var dtRedColorFlow: CGFloat = 0     //second
    public var dxpyramidRedGhost: CGFloat = 0    //pointX
    public var dypyramidRedGhost: CGFloat = 0    //pointY
    
    public var dtBlueColorFlow: CGFloat = 0     //second
    public var dxpyramidBlueGhost: CGFloat = 0    //pointX
    public var dypyramidBlueGhost: CGFloat = 0    //pointY
    
    public var dtGreenColorFlow: CGFloat = 0     //second
    public var dxpyramidGreenGhost: CGFloat = 0    //pointX
    public var dypyramidGreenGhost: CGFloat = 0    //pointY
    
    public var x1 :CGFloat = 0
    public var y1 :CGFloat = 0
    public var mRed :CGFloat = 0
    public var angleRedLight :CGFloat = 0
    public var mBlue:CGFloat = 0
    public var angleBlueLight:CGFloat = 0
    public var mGreen:CGFloat = 0
    public var angleGreenLight:CGFloat = 0
    public var initialRedAngle: CGFloat = 0
    public var initialBlueAngle: CGFloat = 0
    public var initialGreenAngle: CGFloat = 0
    
    //action
    public var lightAnimation : SKAction?
    public var lightOnAnimation : SKAction?
    public var showColor: Bool = false
    public var lightAnimationFinished: Bool = false
    public var startingPoint: CGPoint = CGPoint(x: 0, y: 0)
    public var finalPoint: CGPoint = CGPoint()
    
    
    public override func didMove(to view: SKView) {
        
        self.size = view.frame.size
        
        self.backgroundColor = UIColor(red: 15/255, green: 15/255, blue: 15/255, alpha: 1)
        centerScene = CGPoint(x: size.width/2, y: size.height/2)
        
        //Setup
        pyramidSetup()
        presentationViewSetup()
        torchSetup()
        ghostSetup()
        
        //angleRangeSetup
        if size.width < 400 {
            scaleLight = 0.02
        }else if size.width < 500 {
            scaleLight = 0.06
        }else  if size.width < 600 {
            scaleLight = 0.1
        }else  if size.width < 700 {
            scaleLight = 0.2
        }else  if size.width > 1000 {
            scaleLight = 0.3
        }
        
        //Trigonometry ColorFlow setup
        trigonometrySetup()
        
        //lightSetup
        lightNode = SKEmitterNode(fileNamed: "Light.sks")!
        lightNode.speed = v0LightFlow
        lightNode.particleScale = scaleLight
        
        //addChild
        addChild(pyramidNode)
        pyramidNode.isHidden = true
        addChild(redGhost)
        redGhost.isHidden = true
        addChild(greenGhost)
        greenGhost.isHidden = true
        addChild(blueGhost)
        blueGhost.isHidden = true
        
        addChild(redNode)
        redNode.isHidden = true
        redNode.isPaused = true
        addChild(blueNode)
        blueNode.isHidden = true
        blueNode.isPaused = true
        addChild(greenNode)
        greenNode.isHidden = true
        greenNode.isPaused = true
        
        addChild(torchNode)
        torchNode.isHidden = true
        
        
        addChild(lightNode)
        lightNode.isHidden = true
        lightNode.isPaused = true
        
    }
    
    @objc func startExperiment(sender:UIButton) {
        
        UIView.animate(withDuration: 3, animations: {
            self.instructionView.frame = self.originaFrameView
            self.instructionView.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
        }, completion:{ (true) in
            self.button.removeFromSuperview()
            
            self.pyramidNode.isHidden = false
            
            self.startRedGhostAnimation()
            self.startBlueGhostAnimation()
            self.startGreenGhostAnimation()
            
            self.letsStart = true
            
            self.instructionView.removeFromSuperview()
        })
        
        PlaygroundPage.current.assessmentStatus = .fail(hints: ["Let's touch and hold down the left side of the screen! 👆🏼"], solution: nil)
        playBackgroundMusic(name: "background.mp3")
        
    }
    
    public override func update(_ currentTime: TimeInterval) {
        
    }
    
    //GESTURE
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if letsStart{
            guard let touch = touches.first else {return}
            let touchLocation = touch.location(in: self)
            
            if redGhost.contains(touchLocation){
                selectedNode = redGhost
                ghostTouched = true
            }else if blueGhost.contains(touchLocation){
                selectedNode = blueGhost
                ghostTouched = true
            }else if greenGhost.contains(touchLocation){
                selectedNode = greenGhost
                ghostTouched = true
            }else if touchLocation.x < centerScene.x{
                lightTouched = true
                if touchLocation.y < centerScene.y{
                    dyLightpyramid = abs(touchLocation.y - centerScene.y)
                }else{
                    dyLightpyramid = abs(touchLocation.y - centerScene.y)
                }
                dxLightpyramid = abs(touchLocation.x - centerScene.x)
                
                let dx = centerScene.x - touchLocation.x
                let dy = centerScene.y - touchLocation.y
                let radAngle = atan(dy/dx)
                dtLightFlow = max(dxLightpyramid/v0LightFlow, dyLightpyramid/v0LightFlow)
            
                
                //light
                lightNode.position = touchLocation
                lightNode.emissionAngle = radAngle
                lightNode.particleLifetime = dtLightFlow
                torchNode.isHidden = false
                lightNode.isHidden = false
                lightNode.isPaused = false
                lightNode.resetSimulation()
                
                //torch
                torchNode.position = CGPoint(x: touchLocation.x - cos(radAngle)*0.8*torchNode.frame.width , y: touchLocation.y - sin(radAngle)*0.8*torchNode.frame.width)
                torchNode.zRotation = radAngle
                
                let waitLightArriveTopyramid = SKAction.wait(forDuration: Double(Float(dtLightFlow)))
                
                pyramidNode.run(waitLightArriveTopyramid, completion: {
                    //colorFlow Setup
                    self.redNode.isPaused = false
                    self.redNode.isHidden = false
                    self.redNode.resetSimulation()
                    self.blueNode.isPaused = false
                    self.blueNode.isHidden = false
                    self.blueNode.resetSimulation()
                    self.greenNode.isPaused = false
                    self.greenNode.isHidden = false
                    self.greenNode.resetSimulation()
                    
                    self.ExperimentCompleted = true
                })
            }
        }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if ghostTouched{
            selectedNode.position = (touches.first?.location(in: self))!
        }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if ghostTouched && phase >= 0{
            ghostTouched = false
            updateColorLightParameters()
        }else if lightTouched{
            
            lightTouched = false
            pyramidNode.removeAllActions()
            
            torchNode.isHidden = true
            lightNode.isHidden = true
            lightNode.isPaused = true
            
            redNode.isHidden = true
            redNode.isPaused = true
            blueNode.isHidden = true
            blueNode.isPaused = true
            greenNode.isHidden = true
            greenNode.isPaused = true
            
            if ExperimentCompleted{
                phase = phase + 1
                ExperimentCompleted = false
                if firstTryAgain{
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Try again to light up the Pyramid  👻👻👻"], solution: nil)
                    firstTryAgain = false
                }
            }else{
                if firstFail{
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Touch and hold down until the light reachses the pyramid  👆🏼 ⃤"], solution: nil)
                    firstFail = false
                }
            }
            if phase == 0{
                
                redGhost.run(SKAction.scale(by: 0.2, duration: 0))
                redGhost.isHidden = false
                redGhost.run(SKAction.scale(to: 1, duration: 2))
                
                blueGhost.run(SKAction.scale(by: 0.2, duration: 0))
                blueGhost.isHidden = false
                blueGhost.run(SKAction.scale(to: 1, duration: 2))
                
                greenGhost.run(SKAction.scale(by: 0.2, duration: 0))
                greenGhost.isHidden = false
                greenGhost.run(SKAction.scale(to: 1, duration: 2))
                
            }else if phase >= 1{
                
                let zoomOut = SKAction.scale(by: 2, duration: 1)
                let zoomIn = SKAction.scale(to: 1, duration: 1)
                redGhost.run(SKAction.sequence([zoomOut,zoomIn]))
                blueGhost.run(SKAction.sequence([zoomOut,zoomIn]))
                greenGhost.run(SKAction.sequence([zoomOut,zoomIn]))
                
                
                if phase == 1{
                    redGhostAnimation = SKAction.animate(with: redGhostTextures0,timePerFrame: 0.1)
                    stopRedGhostAnimation()
                    startRedGhostAnimation()
                    blueGhostAnimation = SKAction.animate(with: blueGhostTextures0, timePerFrame: 0.1)
                    stopBlueGhostAnimation()
                    startBlueGhostAnimation()
                    greenGhostAnimation = SKAction.animate(with: greenGhostTextures0, timePerFrame: 0.1)
                    stopGreenGhostAnimation()
                    startGreenGhostAnimation()
                }

                //red
                redGhostColorAnimation = SKAction.colorize(with: newRedColor, colorBlendFactor: 0.5, duration: 0.1)
                stopColorRedGhostAnimation()
                startColorRedGhostAnimation()
                
                //blue
                blueGhostColorAnimation = SKAction.colorize(with: newBlueColor, colorBlendFactor: 0.5, duration: 0.1)
                stopColorBlueGhostAnimation()
                startColorBlueGhostAnimation()
                
                
                //green
                greenGhostColorAnimation = SKAction.colorize(with: newGreenColor, colorBlendFactor: 0.5, duration: 0.1)
                stopColorGreenGhostAnimation()
                startColorGreenGhostAnimation()

                
                if !firstTryAgain{
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["The light follows the ghosts!!! Try to move them! 👻👻👻"], solution: nil)
                    firstTryAgain = true
                }
                
                
            }
            
        }
        
    }
    
    //2 function for each ANIMATION  in order to start and stop it
    //RED
    func startRedGhostAnimation() {
        if redGhost.action(forKey: "redGhostAnimation") == nil {
            redGhost.run(
                SKAction.repeatForever(redGhostAnimation!),
                withKey: "redGhostAnimation")
        }
    }
    
    func stopRedGhostAnimation() {
        redGhost.removeAction(forKey: "redGhostAnimation")
    }
    // NEW RED COLOR
    func startColorRedGhostAnimation() {
        if redGhost.action(forKey: "colorRedGhostAnimation") == nil {
            redGhost.run(
                SKAction.repeatForever(redGhostColorAnimation!),
                withKey: "colorRedGhostAnimation")
        }
    }
    
    func stopColorRedGhostAnimation() {
        redGhost.removeAction(forKey: "colorRedGhostAnimation")
    }
    //BLUE
    func startBlueGhostAnimation() {
        if blueGhost.action(forKey: "blueGhostAnimation") == nil {
            blueGhost.run(
                SKAction.repeatForever(blueGhostAnimation!),
                withKey: "blueGhostAnimation")
        }
    }
    
    func stopBlueGhostAnimation() {
        blueGhost.removeAction(forKey: "blueGhostAnimation")
    }
    // NEW BLUE COLOR
    func startColorBlueGhostAnimation() {
        if blueGhost.action(forKey: "colorBlueGhostAnimation") == nil {
            blueGhost.run(
                SKAction.repeatForever(blueGhostColorAnimation!),
                withKey: "colorBlueGhostAnimation")
        }
    }
    
    func stopColorBlueGhostAnimation() {
        blueGhost.removeAction(forKey: "colorBlueGhostAnimation")
    }
    //GREEN
    func startGreenGhostAnimation() {
        if greenGhost.action(forKey: "greenGhostAnimation") == nil {
            greenGhost.run(
                SKAction.repeatForever(greenGhostAnimation!),
                withKey: "greenGhostAnimation")
        }
    }
    
    func stopGreenGhostAnimation() {
        greenGhost.removeAction(forKey: "greenGhostAnimation")
    }
    // NEW GREEN COLOR
    func startColorGreenGhostAnimation() {
        if greenGhost.action(forKey: "colorGreenGhostAnimation") == nil {
            greenGhost.run(
                SKAction.repeatForever(greenGhostColorAnimation!),
                withKey: "colorGreenGhostAnimation")
        }
    }
    
    func stopColorGreenGhostAnimation() {
        greenGhost.removeAction(forKey: "colorGreenGhostAnimation")
    }
    
    
    public func pyramidSetup(){
        let pyramidaWidth: CGFloat = size.width/3
        let pyramidaHeight: CGFloat = 0.91*pyramidaWidth
        pyramidNode = SKShapeNode(rect: CGRect(x: 0, y: 0, width: pyramidaWidth, height: pyramidaHeight))
        pyramidNode.strokeColor = .clear
        pyramidNode.fillColor = .white
        pyramidNode.fillTexture = SKTexture(imageNamed: "Pyramid")
        pyramidNode.position = CGPoint(x: centerScene.x - pyramidaWidth/2, y: centerScene.y - pyramidaHeight/2)
    }
    
    public func presentationViewSetup(){
        var widthView: CGFloat = 0
        if size.width > size.height{
            widthView = size.width/6
        }else{
            widthView = size.width/3
        }
        let heightView = 0.66*widthView
        
        originaFrameView = CGRect(x: size.width/12 - widthView/2, y: size.height/12 - heightView/2, width: widthView, height: heightView)
        instructionView = UIView(frame: originaFrameView)
        
        button = UIButton()         //button setup
        let widthButton = 0.19*widthView
        let heightButton = 0.27*widthButton
        button.frame = CGRect(x: widthView/2 - widthButton/2, y: heightView*0.8 - heightButton/2, width: widthButton, height: heightButton)
        button.setImage(UIImage(named: "StartButton"), for: .normal)
        button.contentMode = .scaleAspectFit
        button.addTarget(self, action: #selector(startExperiment), for: .touchUpInside)
        
        
        let blackboard = UIImageView(frame: instructionView.bounds)
        blackboard.image = UIImage(named: "BackBoard")
        blackboard.contentMode = .scaleAspectFit
        instructionView.addSubview(blackboard)
        instructionView.addSubview(button)
        
        view?.addSubview(instructionView)
        
        UIView.animate(withDuration: 2, animations: {
            self.instructionView.frame = CGRect(x: self.size.width/2 - widthView/2, y: self.size.height/2 - heightView/2, width: widthView, height: heightView)
            self.instructionView.transform = CGAffineTransform(scaleX: 2.5, y: 2.5)
        }, completion: nil)
        
    }
    
    public func torchSetup(){
        let torchHeight: CGFloat = size.width/24
        let torchWidth: CGFloat = 2.6*torchHeight
        torchNode = SKSpriteNode(imageNamed: "Torch")
        torchNode.size = CGSize(width: torchWidth, height: torchHeight)
        torchNode.zPosition = 1
    }
    
    public func ghostSetup(){
        var ghostWidth: CGFloat = 0
        if size.width > size.height{
            ghostWidth = size.width/8
        }else{
            ghostWidth = size.width/6
        }
        let ghostHeight: CGFloat = 1.14*ghostWidth
        
        redGhost = SKSpriteNode(imageNamed: "Ghost1/Red 1")
        redGhost.zPosition = 2
        redGhost.position = CGPoint(x: 5*size.width/8, y: 7*size.height/8)
        redGhost.size = CGSize(width: ghostWidth, height: ghostHeight)
        var redGhostTextures1: [SKTexture] = []
        redGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Red 1"))
        redGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Red 2"))
        redGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Red 3"))
        redGhostAnimation = SKAction.animate(with: redGhostTextures1,
                                             timePerFrame: 0.1)
        
        
        blueGhost = SKSpriteNode(imageNamed: "Ghost1/Blue 1")
        blueGhost.zPosition = 2
        blueGhost.position = CGPoint(x: 3*size.width/4, y: 3*size.height/4)
        blueGhost.size = CGSize(width: ghostWidth, height: ghostHeight)
        var blueGhostTextures1: [SKTexture] = []
        blueGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Blue 1"))
        blueGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Blue 2"))
        blueGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Blue 3"))
        blueGhostAnimation = SKAction.animate(with: blueGhostTextures1,
                                              timePerFrame: 0.1)
        
        
        greenGhost = SKSpriteNode(imageNamed: "Ghost1/Green 1")
        greenGhost.zPosition = 2
        greenGhost.position = CGPoint(x: 7*size.width/8, y: 5*size.height/8)
        greenGhost.size = CGSize(width: ghostWidth, height: ghostHeight)
        var greenGhostTextures1: [SKTexture] = []
        greenGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Green 1"))
        greenGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Green 2"))
        greenGhostTextures1.append(SKTexture(imageNamed: "Ghost1/Green 3"))
        greenGhostAnimation = SKAction.animate(with: greenGhostTextures1,
                                               timePerFrame: 0.1)
        
        redGhost.isHidden = true
        blueGhost.isHidden = true
        greenGhost.isHidden = true
        redGhost.alpha = 0.8
        blueGhost.alpha = 0.8
        greenGhost.alpha = 0.8
        
        //ghosts Animation Setup
        redGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Red 1"))
        redGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Red 1"))
        redGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Red 2"))
        redGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Red 3"))
        blueGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Blue 1"))
        blueGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Blue 2"))
        blueGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Blue 3"))
        greenGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Green 1"))
        greenGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Green 2"))
        greenGhostTextures0.append(SKTexture(imageNamed: "Ghost0/Green 3"))
        redGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Red 1"))
        redGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Red 1"))
        redGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Red 2"))
        redGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Red 3"))
        blueGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Blue 1"))
        blueGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Blue 2"))
        blueGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Blue 3"))
        greenGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Green 1"))
        greenGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Green 2"))
        greenGhostTextures2.append(SKTexture(imageNamed: "Ghost2/Green 3"))
        redGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Red 1"))
        redGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Red 2"))
        redGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Red 3"))
        blueGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Blue 1"))
        blueGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Blue 2"))
        blueGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Blue 3"))
        greenGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Green 1"))
        greenGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Green 2"))
        greenGhostTextures3.append(SKTexture(imageNamed: "Ghost3/Green 3"))
        
    }
    
    public func updateColorLightParameters(){
        mRed = (self.redGhost.position.y - y1) / (self.redGhost.position.x - x1)    //angular coefficient
        let radRed = atan(mRed)
        if redGhost.position.x < centerScene.x{
            angleRedLight = (radRed*180/CGFloat.pi + 180)   //°
        }else{
            angleRedLight = radRed*180/CGFloat.pi           //°
        }
        redNode.emissionAngle = CGFloat.pi*self.angleRedLight/180                   //new angle (rad)
        let dxCenterRedGhost = abs(centerScene.x - (redGhost.position.x - redGhost.size.width/2))
        let dyCenterRedGhost = abs(centerScene.y - redGhost.position.y)
        dtRedColorFlow = max(dxCenterRedGhost/v0LightFlow, dyCenterRedGhost/v0LightFlow)
        redNode.particleLifetime = dtRedColorFlow                                   //new life time
        
        mBlue = (self.blueGhost.position.y - y1) / (self.blueGhost.position.x - x1) //angular coefficient
        let radBlue = atan(mBlue)
        if blueGhost.position.x < centerScene.x{
            angleBlueLight = (radBlue*180/CGFloat.pi + 180)     //°
        }else{
            angleBlueLight = radBlue*180/CGFloat.pi             //°
        }
        blueNode.emissionAngle = CGFloat.pi*self.angleBlueLight/180                 //new angle (rad)
        let dxCenterBlueGhost = abs(centerScene.x - (blueGhost.position.x - blueGhost.size.width/2))
        let dyCenterBlueGhost = abs(centerScene.y - blueGhost.position.y)
        dtBlueColorFlow = max(dxCenterBlueGhost/v0LightFlow, dyCenterBlueGhost/v0LightFlow)
        blueNode.particleLifetime = dtBlueColorFlow                                   //new life time
        
        mGreen = (self.greenGhost.position.y - y1)/(self.greenGhost.position.x - x1)    //angular coefficient
        let radGreen = atan(mGreen)
        if greenGhost.position.x < centerScene.x{
            angleGreenLight = (radGreen*180/CGFloat.pi + 180)   //°
        } else{
            angleGreenLight = radGreen*180/CGFloat.pi           //°
        }
        greenNode.emissionAngle = CGFloat.pi*self.angleGreenLight/180                   //new angle (rad)
        let dxCenterGreenGhost = abs(centerScene.x - (greenGhost.position.x - greenGhost.size.width/2))
        let dyCenterGreenGhost = abs(centerScene.y - greenGhost.position.y)
        dtGreenColorFlow = max(dxCenterGreenGhost/v0LightFlow, dyCenterGreenGhost/v0LightFlow)
        greenNode.particleLifetime = dtGreenColorFlow                                   //new life time
        
        
        if firstTimeSetup{
            initialRedAngle = redNode.emissionAngle
            initialBlueAngle = blueNode.emissionAngle
            initialGreenAngle = greenNode.emissionAngle
            firstTimeSetup = false
        }
        //new Color linked to ghosts position
        newRedColor = UIColor(red: abs(sin(redNode.emissionAngle + (CGFloat.pi/2 - initialRedAngle))), green: abs(cos(redNode.emissionAngle + (CGFloat.pi/2 - initialRedAngle))), blue: 0, alpha: 1)
        newBlueColor = UIColor(red: abs(cos(blueNode.emissionAngle + (CGFloat.pi/2 - initialBlueAngle))), green: 0, blue: abs(sin(blueNode.emissionAngle + (CGFloat.pi/2 - initialBlueAngle))), alpha: 1)
        newGreenColor = UIColor(red: abs(cos(greenNode.emissionAngle + (CGFloat.pi/2 - initialGreenAngle))), green: abs(sin(greenNode.emissionAngle + (CGFloat.pi/2 - initialGreenAngle))), blue: 0, alpha: 1)
        
        redNode.particleColorSequence = nil
        redNode.particleColorBlendFactor = 0.5
        redNode.particleColor = newRedColor
        
        blueNode.particleColorSequence = nil
        blueNode.particleColorBlendFactor = 0.5
        blueNode.particleColor = newBlueColor
        
        greenNode.particleColorSequence = nil
        greenNode.particleColorBlendFactor = 0.5
        greenNode.particleColor = newGreenColor
        
    }
    
    public func trigonometrySetup(){
        x1 = centerScene.x
        y1 = centerScene.y
        
        //ColorFlow Setup
        redNode = SKEmitterNode(fileNamed: "ColorFlow.sks")!
        redNode.position = CGPoint(x: self.x1, y: self.y1)
        redNode.particleScale = scaleLight/2
        redNode.speed = v0LightFlow
        
        
        blueNode = SKEmitterNode(fileNamed: "ColorFlow.sks")!
        blueNode.position = CGPoint(x: self.x1, y: self.y1)
        blueNode.particleScale = scaleLight/2
        blueNode.speed = v0LightFlow
        
        
        greenNode = SKEmitterNode(fileNamed: "ColorFlow.sks")!
        greenNode.position = CGPoint(x: self.x1, y: self.y1)
        greenNode.particleScale = scaleLight/2
        greenNode.speed = v0LightFlow
        
        updateColorLightParameters()
        
    }
    
    //addictional Function
    public func testSpeed(currentTime: TimeInterval){
        if lastUpdateTime > 0 {
            dt = currentTime - lastUpdateTime
        } else {
            dt = 0
        }
        lastUpdateTime = currentTime
        NSLog("\(dt*1000) milliseconds since last update")
    }
    
    
    //playground music: it have to added in didMove(:) function in order to start from the beginning
    func playBackgroundMusic(name: String) {
        if let backgroundMusic = childNode(withName:
            "backgroundMusic") {
            backgroundMusic.removeFromParent()
        }
        let music = SKAudioNode(fileNamed: name)
        music.name = "backgroundMusic"
        music.autoplayLooped = true
        addChild(music)
    }
    
    //texture animation: u have to call this function if u want to change texture SKNode. the "prefix" is a textureName without final indexNumber
    func setupAnimationWithPrefix(_ prefix: String, start: Int,
                                  end: Int, timePerFrame: TimeInterval) -> SKAction {
        var textures: [SKTexture] = []
        for i in start...end {
            textures.append(SKTexture(imageNamed: "\(prefix)\(i)"))
        }
        return SKAction.animate(with: textures,
                                timePerFrame: timePerFrame)
    }
    
}
