//#-hidden-code
//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.assessmentStatus = .fail(hints: ["Choose one of the three elements 👆🏼"], solution: nil)
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


/*:
 ## **2    Electron Configuration**
 
 **Niels Bohr**, a Danish physicist, that is responsible in large part for the transition to the modern view of the of the atom’s structure, was inspired in his researches by the hydrogen refraction.
    He discovered that electrons move around the atom in discrete energy levels, and, differently from the old theories, not on the same circular orbital.
    He also found out that electrons can move up on an <other energy level if they are charged with enough energy. He called this amount of energy:  **a quantum of energy**.
 
 - callout(Explore): In order to complete the electron configuration, you have to choose one of the three different elements that you can configure:
 
    ![elements](elements.jpg)
    Once you selected the elements, following the electron configuration showed in the bottom of the screen, you have to move the electrons on the correct atomic orbital. The three atomic orbitals necessary for these elements are:
 
    ![atomic orbital](atomicOrbital.jpg)
 
 
 But, how electrons travel around the atom? To answer this question, we have to know another important physicist: **Werner Heisenberg**.
 He found out that we cannot know both the speed and the position of electrons at the same time; this is called the *Heisenberg’s uncertainty principle*.
 So, we can only know the probability that electrons occupy a defined region of the space around the atoms, we call this *the electron cloud model*.
 */
