//  Copyright (c) 2018 Geremia De Micco. All Rights Reserved.

import Foundation
import UIKit
import SpriteKit

public class SKElectron : SKShapeNode{
    
    public init(circleOfRadius: CGFloat, position: CGPoint) {
        super.init()
        self.path = SKShapeNode(circleOfRadius: circleOfRadius).path
        self.position = position
        self.fillColor = .white
        self.strokeColor = .clear
        self.fillTexture = SKTexture(imageNamed: "Electron")
        self.zPosition = 1
        self.isHidden = true
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

