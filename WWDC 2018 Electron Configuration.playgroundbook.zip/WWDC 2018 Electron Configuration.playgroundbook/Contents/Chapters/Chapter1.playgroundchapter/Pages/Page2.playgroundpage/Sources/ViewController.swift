//  Copyright (c) 2018 Geremia De Micco. All Rights Reserved.

import UIKit
import SpriteKit
import PlaygroundSupport

public class ViewController: UIViewController{
    
    public var skView = SKView()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    public override func loadView() {
        super.loadView()
        self.view = UIView()
        
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateViewConstraints()
        skView = SKView(frame: self.view.frame)
        self.view.addSubview(skView)
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        skView.presentScene(ElectronConfigurationScene())
    }
    
}
