//  Copyright (c) 2018 Geremia De Micco. All Rights Reserved.

import Foundation
import SpriteKit
import PlaygroundSupport


public class ElectronConfigurationScene: SKScene{
    
    //gesture
    public var selectedNode = SKShapeNode()
    public var finalPosition = CGPoint()
    public var initialPosition = CGPoint()
    
    //SKShapeNode
    public var electrons = [SKShapeNode]()
    public var index: Int = 0
    public var orbital1S = SKShapeNode()
    public var orbital2S = SKShapeNode()
    public var orbital2P = SKShapeNode()
    public var nucleus = SKShapeNode()
    public var rNucleus = CGFloat()
    public var nucleusAnimation = SKAction()
    
    public var carbon = SKShapeNode()
    public var carbonConfiguration = false
    public var fluorine = SKShapeNode()
    public var fluorineConfiguration = false
    public var nitrogen = SKShapeNode()
    public var nitrogenConfiguration = false
    
    public var configurationStarted: Bool = false
    public var carbonMode: Bool = false
    public var nitrogenMode: Bool = false
    public var fluorineMode: Bool = false
    public var atomCompleted: String = ""
    
    public var mapLegend = SKShapeNode()
    public var electronTouched = false
    public var fireworks = SKEmitterNode()
    public var currentScore = SKSpriteNode()
    public var finalScore = SKSpriteNode()
    
    public var oneTimeHint = true
    
    //Electron configuration
    public var level = 1
    public var electronOnorbital1S = 0
    public var electronOnorbital2S = 0
    public var electronOnorbital2P = 0
    public var electronOnOrbitalD = 0
    
    
    public override func didMove(to view: SKView) {
        self.size = view.frame.size
        
        self.view?.gestureRecognizers?.first?.delaysTouchesBegan = false
        
        self.backgroundColor = UIColor(red: 15/255, green: 15/255, blue: 15/255, alpha: 1)
        
        //nucleus
        rNucleus = 0.05*size.width
        let centerNucleus = CGPoint(x: frame.midX, y: frame.midY)
        nucleusSetup(rNucleus: rNucleus, centerNucleus: centerNucleus)
        
        //elements
        var elemWidth: CGFloat = 0
        if size.width > 1000{
            elemWidth = 0.06*size.width
        }else{
            elemWidth = 0.12*size.width
        }
        let elemHeight = 1.3*elemWidth
        elementsSetup(elemHeight: elemHeight, elemWidth: elemWidth)
        addChild(carbon)
        addChild(fluorine)
        addChild(nitrogen)
        
        //mapLegend and Score
        mapLegendSetup(elemHeight: elemHeight)
        addChild(mapLegend)
        scoreSetup()
        addChild(currentScore)
        addChild(finalScore)
        
        //atomSetup
        atomSetup(rNucleus: rNucleus, centerNucleus: centerNucleus)
        
        fireworks = SKEmitterNode(fileNamed: "fireworks.sks")!
        fireworks.isPaused = true
        fireworks.position = CGPoint(x:centerNucleus.x + size.width/4, y: centerNucleus.y - size.height/4)
        
        addChild(fireworks)
        addChild(nucleus)
        addChild(orbital2P)
        addChild(orbital2S)
        addChild(orbital1S)
        playBackgroundMusic(name: "background.mp3")

        
    }
    
    
    public override func update(_ currentTime: TimeInterval) {
        if currentScore.isHidden == false{
            currentScore.texture = SKTexture(imageNamed: "ElectronConfiguration/Current/1S\(electronOnorbital1S) 2S\(electronOnorbital2S) 2P\(electronOnorbital2P)")
        }
    }
    
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else {return}
        let touchLocation = touch.location(in: self)
        
        if !configurationStarted{                   //ancora devo scegliere l'elemento da configurare
            if carbon.contains(touchLocation){
                nitrogen.alpha = 0.2
                fluorine.alpha = 0.2
                carbonMode = true
                configurationStarted = true
                if oneTimeHint{
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Move the electrons on the correct atomic orbital"], solution: nil)
                }
                finalScore.texture = SKTexture(imageNamed: "ElectronConfiguration/Final/1S2 2S2 2P2")
                finalScore.isHidden = false
                currentScore.isHidden = false
                showElectron()
            }else if nitrogen.contains(touchLocation){
                carbon.alpha = 0.2
                fluorine.alpha = 0.2
                nitrogenMode = true
                configurationStarted = true
                if oneTimeHint{
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Move the electrons on the correct atomic orbital"], solution: nil)
                }
                finalScore.texture = SKTexture(imageNamed: "ElectronConfiguration/Final/1S2 2S2 2P3")
                finalScore.isHidden = false
                currentScore.isHidden = false
                showElectron()
            }else if fluorine.contains(touchLocation){
                nitrogen.alpha = 0.2
                carbon.alpha = 0.2
                fluorineMode = true
                configurationStarted = true
                if oneTimeHint{
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Move the electrons on the correct atomic orbital"], solution: nil)
                }
                finalScore.texture = SKTexture(imageNamed: "ElectronConfiguration/Final/1S2 2S2 2P5")
                finalScore.isHidden = false
                currentScore.isHidden = false
                showElectron()
            }
        }else{
            
            let touchedNode = self.nodes(at: touchLocation).first
            
            if touchedNode is SKShapeNode {
                let node = touchedNode as! SKShapeNode
                if node == electrons[index]{
                    initialPosition = electrons[index].position
                    selectedNode = electrons[index]
                    electronTouched = true
                }else if node == electrons[index + 1]{
                    initialPosition = electrons[index + 1].position
                    selectedNode = electrons[index + 1]
                    electronTouched = true
                }
            }
        }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if electronTouched{
            selectedNode.position = (touches.first?.location(in: self))!
        }
        
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if electronTouched{
            finalPosition = selectedNode.position
            selectedNode.position = initialPosition
            electronTouched = false
            if level == 1{
                if orbital1S.contains(finalPosition){
                    addElectron(orbital: orbital1S)
                    electronOnorbital1S += 1
                    if electronOnorbital1S == 2{
                        index += 2
                        showElectron()
                        //LEVEL COMPELTED!!!!
                        level = 2
                        //REMOVE LAST LEVEL ORBITAL AND ADD OTHER (or CHANGE COLOR and REMOVE ALL ELECTRONS)
                    }
                }
                
                
            }else if level == 2{
                if electronOnorbital2S < 2{
                    if orbital2S.contains(finalPosition){
                        addElectron(orbital: orbital2S)
                        electronOnorbital2S += 1
                        if electronOnorbital2S == 2{
                            //ADD 2 ELECTRONS IN THE VIEW
                            index += 2
                            showElectron()
                            
                        }
                    }
                }else if electronOnorbital2P < 6{    //orb 2S completed!
                    
                    if orbital2P.contains(finalPosition){
                        addElectron(orbital: orbital2P)
                        electronOnorbital2P += 1
                        
                        if electronOnorbital2P == 2{
                            if carbonMode{
                                //CARBON COMPLETED
                                //MUSIC AND SOMEOTHERTHING
                                atomCompleted = "Carbon"
                                configurationEnded()
                                
                            }else if nitrogenMode{
                                index += 1
                                electrons[index + 1].run(SKAction.scale(by: 0.2, duration: 0))
                                electrons[index + 1].isHidden = false
                                electrons[index + 1].run(SKAction.scale(to: 1, duration: 1))
                                
                            }else{
                                //ADD 2 ELECTRONS IN THE VIEW
                                index += 2
                                showElectron()
                            }
                        }else if electronOnorbital2P == 3 && nitrogenMode{
                            //NITROGE COMPLETED
                            //MUSIC AND SOMEOTHERTHING
                            atomCompleted = "Nitrogen"
                            configurationEnded()
                            
                        }else if electronOnorbital2P == 4{
                            if fluorineMode{
                                index += 1
                                electrons[index].run(SKAction.scale(by: 0.2, duration: 0))
                                electrons[index + 1].isHidden = false
                                electrons[index + 1].run(SKAction.scale(to: 1, duration: 1))
                            }else{
                                //ADD 2 ELECTRONS IN THE VIEW
                                index += 2
                                showElectron()
                            }
                        }else if electronOnorbital2P == 5{
                            //MUSIC AND SOMEOTHERTHING
                            //FLUORINE COMPLETED
                            atomCompleted = "Fluorine"
                            configurationEnded()
                            
                        }else if electronOnorbital2P == 6{
                            level = 3
                        }
                    }
                }
            }
        }
    }
    
    
    public func addElectron(orbital: SKShapeNode){
        //action setup
        let pathToFollow = orbital.path
        let moveElectronAction = SKAction.follow(pathToFollow!, asOffset: false, orientToPath: true, speed: 500)
        selectedNode.run(SKAction.repeatForever(moveElectronAction))
    }
    
    public func showElectron(){
        
        electrons[index].run(SKAction.scale(by: 0.2, duration: 0))
        electrons[index + 1].run(SKAction.scale(by: 0.2, duration: 0))
        electrons[index].isHidden = false
        electrons[index + 1].isHidden = false
        electrons[index].run(SKAction.scale(to: 1, duration: 1))
        electrons[index + 1].run(SKAction.scale(to: 1, duration: 1))
        
    }
    
    
    public func nucleusSetup(rNucleus: CGFloat, centerNucleus: CGPoint){
        nucleus = SKShapeNode(circleOfRadius: rNucleus)
        nucleus.fillColor = .white
        nucleus.fillTexture = SKTexture(imageNamed: "NucleusTexture")
        nucleus.strokeColor = .clear
        nucleus.position = centerNucleus
        
        var nucleusTexture: [SKTexture] = []
        nucleusTexture.append(SKTexture(imageNamed: "Nucleus/Nucleus1"))
        nucleusTexture.append(SKTexture(imageNamed: "Nucleus/Nucleus2"))
        nucleusTexture.append(SKTexture(imageNamed: "Nucleus/Nucleus3"))
        nucleusTexture.append(SKTexture(imageNamed: "Nucleus/Nucleus4"))
        nucleusAnimation = SKAction.animate(with: nucleusTexture,
                                            timePerFrame: 0.2)
    }
    
    func startNucleusAnimation() {
        nucleus.run(SKAction.repeatForever(nucleusAnimation),
                    withKey: "nucleusAnimation")
    }
    
    func stopNucleusAnimation() {
        nucleus.removeAction(forKey: "nucleusAnimation")
    }
    
    public func elementsSetup(elemHeight: CGFloat, elemWidth:CGFloat){
        
        carbon = SKShapeNode(rect: CGRect(x: 0, y: 0, width: elemWidth , height: elemHeight))
        carbon.fillColor = .white
        carbon.fillTexture = SKTexture(imageNamed: "Elements/Carbon")
        carbon.position = CGPoint(x: size.width/6 - elemWidth/2, y: 5*size.height/6 - elemHeight/2)
        carbon.strokeColor = .clear
        
        fluorine = SKShapeNode(rect: CGRect(x: size.width/6 - elemWidth/2, y: 5*size.height/6 - 2*elemHeight, width: elemWidth , height: elemHeight))
        fluorine.fillColor = .white
        fluorine.fillTexture = SKTexture(imageNamed: "Elements/Fluorine")
        fluorine.strokeColor = .clear
        
        nitrogen = SKShapeNode(rect: CGRect(x: size.width/6 - elemWidth/2, y:  5*size.height/6 - 7*elemHeight/2, width: elemWidth , height: elemHeight))
        nitrogen.fillColor = .white
        nitrogen.fillTexture = SKTexture(imageNamed: "Elements/Nitrogen")
        nitrogen.strokeColor = .clear
        
    }
    
    public func mapLegendSetup(elemHeight: CGFloat){
        let mapLegendHeight: CGFloat = 3*elemHeight/2
        let mapLegendWidth: CGFloat = 0.8*mapLegendHeight
        mapLegend = SKShapeNode(rect: CGRect(x: 0, y: 0, width: mapLegendWidth, height: mapLegendHeight))
        mapLegend.position = CGPoint(x: 5*size.width/6 - mapLegendWidth/2, y: 5*size.height/6 - 4*mapLegendHeight/5)
        mapLegend.strokeColor = .clear
        mapLegend.fillColor = .white
        mapLegend.fillTexture = SKTexture(imageNamed: "MapLegend")
    }
    
    public func atomSetup(rNucleus: CGFloat, centerNucleus: CGPoint){
        //electrons
        electronsSetup()
        
        //orbitals
        let radius:CGFloat = rNucleus*4
        
        //obitalP
        let pathorbital2P = UIBezierPath()
        pathorbital2P.move(to: CGPoint(x: centerNucleus.x, y: centerNucleus.y))
        
        pathorbital2P.addCurve(to: CGPoint(x: centerNucleus.x + radius/2, y: centerNucleus.y + radius), controlPoint1: CGPoint(x: centerNucleus.x + radius/4, y: centerNucleus.y + radius/2), controlPoint2: CGPoint(x: centerNucleus.x + radius/2, y: centerNucleus.y + 3*radius/4))
        
        pathorbital2P.addArc(withCenter: CGPoint(x: centerNucleus.x,y: centerNucleus.y + radius ), radius: radius/2, startAngle: 0, endAngle: CGFloat.pi, clockwise: true)
        
        pathorbital2P.addCurve(to: CGPoint(x: centerNucleus.x, y: centerNucleus.y), controlPoint1: CGPoint(x: centerNucleus.x - radius/2, y: centerNucleus.y + 3*radius/4), controlPoint2: CGPoint(x: centerNucleus.x - radius/4, y: centerNucleus.y + radius/2))
        
        pathorbital2P.addCurve(to: CGPoint(x: centerNucleus.x + radius/2, y: centerNucleus.y - radius), controlPoint1: CGPoint(x: centerNucleus.x + radius/4, y: centerNucleus.y - radius/2), controlPoint2: CGPoint(x: centerNucleus.x + radius/2, y: centerNucleus.y - 3*radius/4))
        
        pathorbital2P.addArc(withCenter: CGPoint(x: centerNucleus.x,y: centerNucleus.y - radius ), radius: radius/2, startAngle: 0, endAngle: CGFloat.pi, clockwise: false)
        
        pathorbital2P.addCurve(to: CGPoint(x: centerNucleus.x, y: centerNucleus.y), controlPoint1: CGPoint(x: centerNucleus.x - radius/2, y: centerNucleus.y - 3*radius/4), controlPoint2: CGPoint(x: centerNucleus.x - radius/4, y: centerNucleus.y - radius/2))
        
        orbital2P = SKShapeNode(path: pathorbital2P.cgPath)
        orbital2P.lineWidth = 3
        orbital2P.fillColor = .white
        orbital2P.fillTexture = SKTexture(imageNamed: "OrbitalPTexture")
        orbital2P.strokeColor = .clear
        orbital2P.alpha = 0.7
        
        
        //orbital1S setup
        let orbitalWidh = 2*radius
        let orbitalHeight = radius
        
        // create oval centered at (0, 0)
        let path1S = UIBezierPath(ovalIn: CGRect(x: -orbitalWidh/2, y: -orbitalHeight/2, width: orbitalWidh, height: orbitalHeight))
        // rotate it 30 degrees
        path1S.apply(CGAffineTransform(rotationAngle: 30*CGFloat.pi/180))
        // translate it to where you want it
        path1S.apply(CGAffineTransform(translationX: centerNucleus.x, y: centerNucleus.y))
        
        
        orbital1S = SKShapeNode(path: path1S.cgPath)
        orbital1S.lineWidth = 3
        orbital1S.alpha = 1
        orbital1S.fillColor = .white
        orbital1S.fillTexture = SKTexture(imageNamed: "Orbital1STexture")
        orbital1S.strokeColor = .clear
        orbital1S.position = CGPoint(x: 0, y: 0)
        
        //orbital2S setup
        let path2S =  UIBezierPath(ovalIn: CGRect(x: -orbitalWidh/2, y: -orbitalHeight/2, width: orbitalWidh, height: orbitalHeight))
        // rotate it 30 degrees
        path2S.apply(CGAffineTransform(rotationAngle: -30*CGFloat.pi/180))
        // translate it to where you want it
        path2S.apply(CGAffineTransform(translationX: centerNucleus.x, y: centerNucleus.y))
        orbital2S = SKShapeNode(path: path2S.cgPath)
        orbital2S.lineWidth = 3
        orbital2S.alpha = 1
        orbital2S.fillColor = .white
        orbital2S.fillTexture = SKTexture(imageNamed: "Orbital2STexture")
        orbital2S.strokeColor = .clear
        orbital2S.position = CGPoint(x: 0, y: 0)
        
    }
    
    
    public func electronsSetup(){
        for i in 0...12{
            if i%2 == 0{
                electrons.append(SKElectron(circleOfRadius: rNucleus/3, position: CGPoint(x: size.width/6, y: size.height/6)))
            }else{
                electrons.append(SKElectron(circleOfRadius: rNucleus/3, position: CGPoint(x: size.width/3, y: size.height/6)))
            }
        }
        for i in 0...(electrons.count - 1){
            self.addChild(electrons[i])
        }
    }
    
    public func restartElectronSetup(){
        for i in 0...12{
            electrons[i].run(SKAction.scale(by: 0.01, duration: 1))
        }
        electrons.removeAll()
        electronsSetup()
    }
    
    public func configurationEnded(){
        index = 0
        level = 1
        electronOnorbital1S = 0
        electronOnorbital2S = 0
        electronOnorbital2P = 0
        electronOnOrbitalD = 0
        
        PlaygroundPage.current.assessmentStatus = .fail(hints: ["## \(self.atomCompleted) atomic configuration completed!"], solution: nil)
        atomCompleted = ""
        carbonMode = false
        nitrogenMode = false
        fluorineMode = false
        
        startNucleusAnimation()
        fireworks.isPaused = false
        fireworks.resetSimulation()
        let fireworksSound = SKAction.playSoundFileNamed("fireworks.wav",
                                                        waitForCompletion: false)
        run(fireworksSound)
        fireworks.run(SKAction.wait(forDuration: 0.9), completion: {
            self.fireworks.position = CGPoint(x: self.size.width/2 - self.size.width/4, y: self.size.height/2 + self.size.height/4)
            self.fireworks.resetSimulation()
            self.run(fireworksSound)
        })
        fireworks.run(SKAction.wait(forDuration: 1.9), completion: {
            self.fireworks.position = CGPoint(x:self.size.width/2 + self.size.width/4, y: self.size.height/2 + self.size.height/4)
            self.fireworks.resetSimulation()
            self.run(fireworksSound)
        })
        fireworks.run(SKAction.wait(forDuration: 2.9), completion: {
            self.fireworks.resetSimulation()
            self.fireworks.position = CGPoint(x:self.size.width/2 - self.size.width/4, y: self.size.height/2 - self.size.height/4)
            self.restartElectronSetup()
            self.finalScore.isHidden = true
            self.currentScore.isHidden = true
            self.currentScore.texture = SKTexture(imageNamed: "ElectronConfiguration/Current/1S0 2S0 2P0")
            self.configurationStarted = false
            self.carbon.alpha = 1
            self.nitrogen.alpha = 1
            self.fluorine.alpha = 1
        })
    }
    
    public func scoreSetup(){
        
        var width: CGFloat = 6*size.width/14
        if size.width > 1000{
            width = 6*size.width/29
        }
        let height: CGFloat = 0.12*width
        currentScore = SKSpriteNode(imageNamed: "ElectronConfiguration/Current/1S0 2S0 2P0")
        currentScore.size = CGSize(width: width, height: height)
        currentScore.position = CGPoint(x: 7*size.width/8 - width/2, y: size.height/6 + 2*height/3)
        currentScore.isHidden = true
        
        finalScore = SKSpriteNode(imageNamed: "ElectronConfiguration/Final/1S2 2S2 2P2")
        finalScore.size = CGSize(width: width, height: height)
        finalScore.position = CGPoint(x: 7*size.width/8 - width/2, y: size.height/6 - 2*height/3)
        finalScore.isHidden = true
    }
    
    //playground music: it have to added in didMove(:) function in order to start from the beginning
    func playBackgroundMusic(name: String) {
        if let backgroundMusic = childNode(withName:
            "backgroundMusic") {
            backgroundMusic.removeFromParent()
        }
        let music = SKAudioNode(fileNamed: name)
        music.name = "backgroundMusic"
        music.autoplayLooped = true
        addChild(music)
    }
    
}
