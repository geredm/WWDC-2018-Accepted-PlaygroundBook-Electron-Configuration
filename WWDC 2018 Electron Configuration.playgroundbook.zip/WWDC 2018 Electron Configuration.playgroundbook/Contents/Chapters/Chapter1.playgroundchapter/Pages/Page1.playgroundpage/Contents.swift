//#-hidden-code
//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.assessmentStatus = .fail(hints: [], solution: nil)
PlaygroundPage.current.liveView = ViewController()

//#-end-hidden-code

/*:
 In this playground page we’ll discover how the experiment of light reflaction has influenced the discovery of the atomic model.
 
 ## **Introduction - Discovery of Atoms**
 
 Story goes that **Democritus**, an ancient greek philosopher who lived around 400 a.C., while he was walking on the sand,
 thought that sand was composed of pebbles which could have been divided in other little pebbles.
 Questo processo si sarebbe ripetuto finche I granelli non avessero raggiunto una dimensione tale da non essere più divisibili
 In his opinion, this iterative process would be continued until the new, little, pebbles couldn't break again.
 
 
 Only in the early 1800, a man named John Dalton developed the *atomic theory*, based on the observations concerning his experiments.
 He came to the conclusion that **the atoms were indivisible** just like Democritus supposed thousand years ago.
 
 The interest for the atomic theory increased exponentially:
 
 - 1904 **J.J. Thomson** supposed that the atoms consisted of a positive charges, uniformly distributed, in which were present the electrons, negatively charged.
 - 1911 **Ernest Rutherford** is famous for the discovery of a particle of the atom, positively charged, that's called proton. He assumed that the electrons were distributed around the atoms and that the nucleus of the atom was positively charged
 
 ## **1    The refraction of light**
 
 Before completing the atomic model history, we have to remember that *most of what is known about atomic (and
 molecular) structure and mechanics has been deduced from spectroscopy*.
 
 The first person to realize that the white light was made up of rainbow’s colors was **Isaac Newton**, who in
 1666 passed sunlight initially through a narrow slit, then through a prism, in order to project the colored spectrum on to a wall.
 
 Newton clarified the experiment lighting a second prism with a beam of light of a single color; He discovered that the refracted light did not change color.
 
 In this way he concluded that only the white light was made up of all the colors of the rainbow.
 
 But if we tried the same experiment with a source of light produced by a gas, we would discover two different kind of spectrum:
 -A continuous spectrum can be produced by an incandescent solid or by a gas at high pressure.
 -***An emission spectrum RAW can be produced by a gas at low pressure excited by heat or by collisions with electrons.**
 
 This last experiment can be emulated running the code, where the torch represents the source of light.
 
 [Next, explore how the electrons are really positioned >>](@next)
 

 */



