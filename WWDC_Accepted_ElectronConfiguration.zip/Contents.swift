//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import PlaygroundSupport

public class SkScene: SKScene{
    
    //SKSpriteNode
    public var prismNode = SKSpriteNode()
    public var lightShapeNode = SKSpriteNode()
    public var sizeView = CGSize()
    
    //SKEmitterNode
    public var lightNode = SKEmitterNode()
    public var blueNode = SKEmitterNode()
    
    //debug Properties
    public var lastUpdateTime :TimeInterval = 0
    public var dt: TimeInterval = 0
    public var i: Int = 0
    public var lastPositionNode = CGPoint()
    public var dtLightFlow: CGFloat = 0     //second
    public var v0LightFlow: CGFloat = 80    //point/second
    public var dxLightPrism: CGFloat = 0    //pointX
    public var dyLightPrism: CGFloat = 0    //pointY

    
    //action
    public var lightAnimation : SKAction?
    public var lightOnAnimation : SKAction?
    public var showColor: Bool = false
    public var lightAnimationFinished: Bool = false
    public var startingPoint: CGPoint = CGPoint(x: 0, y: 0)
    public var finalPoint: CGPoint = CGPoint()
    
    
    
    //init
    public override init(size: CGSize) {
        super.init(size: size)
        sizeView = size
        finalPoint = CGPoint(x: sizeView.width/2 - 30, y: sizeView.height/2)
        print("initSKScene")
        self.backgroundColor = UIColor.darkGray
        self.scaleMode = .resizeFill
        
        //animation and texture
        var textures : [SKTexture] = []
        
        textures.append( SKTexture(imageNamed: "PrismRed"))
        textures.append( SKTexture(imageNamed: "Prism"))
        
        lightAnimation = SKAction.animate(with: textures,
                                           timePerFrame: 0.1)
        
        
        
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /*DIDMOVE()
     SpriteKit calls the method didMove(to:)
     before it presents your scene in a view; it’s a good place to do some initial setup of your
     scene’s contents.*/
    public override func didMove(to view: SKView) {
        
        //prisma setup
        prismNode = SKSpriteNode(imageNamed: "Prism")
        print("position Prism: \(CGPoint(x: UIScreen.main.bounds.width/2, y: UIScreen.main.bounds.height/2))")
        
        prismNode.position = CGPoint(x: sizeView.width/2, y: sizeView.height/2)
        
        /* To rotate a sprite,set its zRotation property
         This is in Radian */
        //        prismNode.zRotation = CGFloat.pi/6

        
        let pathToFollow = CGMutablePath()
        pathToFollow.move(to: CGPoint(x: 0, y: sizeView.height/2))
        pathToFollow.addLine(to: finalPoint)
        
        addChild(prismNode)
        
        //nodeLight
//        for i in 0...7{
//            let pathLight = UIBezierPath()
//            pathLight.move(to: CGPoint(x: 0, y: i*70))
//            pathLight.addLine(to: finalPoint)
//            //            pathLight.close()
//            lightOnAnimation = SKAction.follow(pathLight.cgPath, duration: 3)
//
//            let rect = CGRect(x: 0, y: 0, width: 1, height: 20)
//            let lightNode = SKShapeNode(rect: rect)
        
//            let actionColor = SKAction.customAction(withDuration: 0.1, actionBlock: { (node, float) in
//                let lightNode2 = node as! SKShapeNode
//
//                lightNode2.strokeColor = UIColor(red: color, green: float*0.1, blue: color, alpha: color)
//            })
//
//            addChild(lightNode)
////
////            lightNode.run(actionColor)
//
//            lightNode.run(lightOnAnimation!, completion: {
//                lightNode.removeFromParent()
//                self.showColor = true
//            })
//        }
    }
    
    
    public override func update(_ currentTime: TimeInterval) {
        
        if showColor{
            showColor = false
            print("Ciao")
            blueNode = SKEmitterNode(fileNamed: "Color.sks")!
            blueNode.position = startingPoint
            blueNode.particleColor = UIColor.red
            self.addChild(blueNode)
        }
        
    }
    
    
    
    //GESTURE
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else {return}
        let touchLocation = touch.location(in: self)
        
        if self.atPoint(touchLocation) == prismNode{
            //
        }
    
        
        dxLightPrism = abs(touchLocation.x - prismNode.position.x + 3*prismNode.size.width/4)
        dyLightPrism = abs(touchLocation.y - prismNode.position.y + 3*prismNode.size.height/4)
        
        dtLightFlow = max(dxLightPrism/v0LightFlow, dyLightPrism/v0LightFlow)
        print("dx = \(dxLightPrism) point\nv0 = \(v0LightFlow) point/s\ndt = \(Double(Float(dtLightFlow))) second")
        
        lightNode = SKEmitterNode(fileNamed: "MyParticle.sks")!
        lightNode.position = touchLocation
        
        let waitLightArriveToPrism = SKAction.wait(forDuration: Double(Float(dtLightFlow)))
    
        prismNode.run(waitLightArriveToPrism, completion: {
            self.showColor = true
        })
//    prismNode.run(SKAction.sequence([waitLightArriveToPrism,SKAction.repeatForever(lightAnimation!)]))
        addChild(lightNode)
    }
    
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        lightNode.run(SKAction.removeFromParent())
        prismNode.removeAllActions()
        blueNode.run(SKAction.removeFromParent())
    }
    
    
    //for each ANIMATION is better do 2 function in order to start and stop it
    func startLightAnimation() {
        if prismNode.action(forKey: "animation") == nil {
            prismNode.run(
                SKAction.repeatForever(lightAnimation!),
                withKey: "animation")
        }
    }

    func stopLightAnimation() {
        prismNode.removeAction(forKey: "animation")
    }
    
    
    //addictional Function
    public func testSpeed(currentTime: TimeInterval){
        if lastUpdateTime > 0 {
            dt = currentTime - lastUpdateTime
        } else {
            dt = 0
        }
        lastUpdateTime = currentTime
        print("\(dt*1000) milliseconds since last update")
    }
    
    func explosion() -> SKEmitterNode {
        let emitter = SKEmitterNode()
        let particleTexture = SKTexture(imageNamed: "Light")
        emitter.particleTexture = particleTexture
        
        emitter.particleBirthRate = 2500
        emitter.particleLifetime = 8
        
        emitter.emissionAngle = 0
        emitter.emissionAngleRange = CGFloat.pi/4

        emitter.xAcceleration = 0
        emitter.yAcceleration = 0
        emitter.speed = v0LightFlow      //points per second
        
        emitter.particleSpeedRange = 100
        
        emitter.particleAlpha = 1
        emitter.particleAlphaRange = 0.2
        emitter.particleAlphaSpeed = 0
        
        emitter.particleScale = 0.2
        emitter.particleScaleRange = 0.2
        emitter.particleScaleSpeed = 0
        
        emitter.particleColor = SKColor.white
        emitter.particleColorRedRange = 255/255
        emitter.particleColorGreenRange = 252/255
        emitter.particleColorBlueRange = 212/255
        emitter.particleRotation = 0

        return emitter
    }
    
    //playground music: it have to added in didMove(:) function in order to start from the beginning
    func playBackgroundMusic(name: String) {
        if let backgroundMusic = childNode(withName:
            "backgroundMusic") {
            backgroundMusic.removeFromParent()
        }
        let music = SKAudioNode(fileNamed: name)
        music.name = "backgroundMusic"
        music.autoplayLooped = true
        addChild(music)
        
    }
    
    //texture animation: u have to call this function if u want to change texture SKNode. the "prefix" is a textureName without final indexNumber
    func setupAnimationWithPrefix(_ prefix: String, start: Int,
                                  end: Int, timePerFrame: TimeInterval) -> SKAction {
        var textures: [SKTexture] = []
        for i in start...end {
            textures.append(SKTexture(imageNamed: "\(prefix)\(i)"))
        }
        return SKAction.animate(with: textures,
                                timePerFrame: timePerFrame)
    }
        
    
}

public class prismViewController: UIViewController{

    //SKView definition
    public var skView = SKView()

    public override func viewDidLoad() {
        super.viewDidLoad()
        print("VC viewDidiLoad")
    }

    public override func loadView() {
        let view = SKView()
        self.view = view
    }

    public override func viewDidLayoutSubviews() {

    }

    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("VC viewWillAppear")
        print("sizeView: \(view.frame.size)")
        //SKScene instance
        print(view.frame)
        let scene = SkScene(size: view.frame.size)
        scene.scaleMode = .resizeFill

        skView = self.view as! SKView

        skView.frame.size = scene.frame.size

        skView.showsFPS = true
        skView.showsNodeCount = true

        skView.presentScene(scene)
        //SKScene start!!!! Presented!!! ->>>>>>>>>>
    }
}


PlaygroundPage.current.liveView = prismViewController()
