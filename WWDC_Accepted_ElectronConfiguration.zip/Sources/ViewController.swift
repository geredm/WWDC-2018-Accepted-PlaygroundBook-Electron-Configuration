import Foundation
import SpriteKit
import UIKit


//public class prismViewController: UIViewController{
//    
//    //SKView definition
//    public var skView = SKView()
//    
//    public override func viewDidLoad() {
//        super.viewDidLoad()
//        print("VC viewDidiLoad")
//        
//        
//    }
//    
//    public override func loadView() {
//        let view = SKView()
//        self.view = view
//    }
//    
//    public override func viewDidLayoutSubviews() {
//        
//    }
//    
//    public override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(true)
//        print("VC viewWillAppear")
//        print("sizeView: \(view.frame.size)")
//        //SKScene instance
//        print(view.frame)
//        let scene = SkScene(size: view.frame.size)
//        scene.scaleMode = .resizeFill
//        
//        skView = self.view as! SKView
//        
//        skView.frame.size = scene.frame.size
//        
//        skView.showsFPS = true
//        skView.showsNodeCount = true
//        
//        skView.presentScene(scene)
//        //SKScene start!!!! Presented!!! ->>>>>>>>>>
//    }
//}

